/*
 * ptrilu.h
 */

#include <matrix.h>

int ptrilu0(int, vector, vector, vector, vector, vector);
int ptrisol0(int, vector, vector, vector, vector, vector, vector);
int ptrilu1(int, vector, vector, vector, vector, vector);
int ptrisol1(int, vector, vector, vector, vector, vector, vector);
