int  open_gnuplot();
void close_gnuplot();
int disk(int, int, matrix, char *);
