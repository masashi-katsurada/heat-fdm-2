/*
 * call_gnuplot.h --- version 2
 */

int  open_gnuplot(void);
int  open_gnuplot2(void);
void close_gnuplot();
int disk(int, int, matrix, char *);
int disk2(int, int, matrix, char *, char *);
