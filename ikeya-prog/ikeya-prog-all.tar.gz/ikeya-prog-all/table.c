#include<stdio.h>
#include<math.h>

int main()
{
  int d;
  double deg, pi;

  pi = 4 * atan(1.0);
  /*$B#3#6#0EY$,#2&P%i%8%"%s$J$N$G!"(B1$BEY$O&P!?#1#8#0%i%8%"%s(B*/
 deg = pi / 180 ;
 for(d= 0; d <= 90; d++){
  printf("%2d  %1.7f %1.7f\n", d,sin(d * deg),cos(d * deg));
 }
  return 0;
}
