/*
 * lu.h
 */

void decomp(int, double **, double *, int *, double *);
void solve(int, double **, double *, int *);
