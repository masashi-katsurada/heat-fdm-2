/*
 * bandlu.h
 * bandtest1.c �򻲹�
 */

#include <matrix.h>

void bandlu(matrix a, int n, int m);
void bandsolve(matrix a, vector b, int n, int m);
